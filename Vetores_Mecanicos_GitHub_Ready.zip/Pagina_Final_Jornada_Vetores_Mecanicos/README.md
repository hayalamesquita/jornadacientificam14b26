# Vetores Mecânicos — Grupo 3

Página interativa oficial do projeto **Grupo 3 — Vetores Mecânicos**, desenvolvida para a Jornada Científica do 4º ano.

**Autores:** João Gabriel • Marcel • João Antônio • Enzo • Estevão • Lorenzo

## O que é este projeto

Este repositório contém o **produto final que será acessado pelo público da feira**. A experiência foi desenhada para permitir que o visitante explore os animais, compreenda como microrganismos podem ser transportados, conheça doenças e agentes relacionados e veja formas de prevenção.

A navegação científica principal é:

**ANIMAL → MICRÓBIO → DOENÇA → TRANSMISSÃO → PREVENÇÃO**

Também existe o caminho inverso, começando por uma doença ou agente e destacando os animais relacionados.

## Tecnologias

- HTML5
- CSS3
- JavaScript puro (Vanilla JS)
- Sem framework
- Sem banco de dados
- Sem dependências obrigatórias
- Funciona em navegador moderno e pode ser hospedado como site estático no GitHub Pages

## Estrutura do repositório

```text
.
├── index.html                    # Página principal publicada
├── style.css                     # Aparência e responsividade
├── script.js                     # Conteúdo dos animais + interações
├── assets/
│   └── img/                      # Imagens dos animais
├── docs/
│   ├── ARQUITETURA.md
│   ├── GUIA_TESTES.md
│   ├── GUIA_PUBLICACAO_GITHUB.md
│   ├── GUIA_EDICAO_CONTEUDO.md
│   └── CHECKLIST_FEIRA.md
├── scripts/
│   └── validate_project.py       # Validação técnica leve
├── .github/workflows/pages.yml  # Publicação automática no GitHub Pages
├── .vscode/                      # Sugestões para trabalhar no VS Code
├── .nojekyll                     # Garante publicação estática direta
├── CHANGELOG.md                  # Histórico das versões
├── CONTRIBUTING.md               # Regras para colaboração
└── README.md
```

## Como abrir no VS Code

1. Descompacte a pasta do projeto.
2. Abra o VS Code.
3. Vá em **File > Open Folder** e escolha a pasta do projeto.
4. Abra `index.html`.
5. Preferencialmente instale a extensão **Live Server** sugerida pelo VS Code.
6. Clique com o botão direito em `index.html` e escolha **Open with Live Server**.
7. O site deve abrir em `http://127.0.0.1:5500/` ou endereço semelhante.

Também é possível iniciar um servidor local no terminal, se Python estiver instalado:

```bash
python -m http.server 5500
```

Depois, abra `http://localhost:5500`.

> Evite testar apenas com duplo clique em `index.html`. Embora a página seja estática, usar um servidor local reproduz melhor o comportamento do GitHub Pages.

## Validação rápida antes de publicar

No terminal do VS Code:

```bash
python scripts/validate_project.py
```

Se o Node.js estiver instalado, também vale conferir a sintaxe do JavaScript:

```bash
node --check script.js
```

Depois execute os testes manuais descritos em [`docs/GUIA_TESTES.md`](docs/GUIA_TESTES.md).

## Publicação

O repositório já inclui um workflow de GitHub Pages. O passo a passo completo está em:

[`docs/GUIA_PUBLICACAO_GITHUB.md`](docs/GUIA_PUBLICACAO_GITHUB.md)

Resumo:

1. Criar um repositório no GitHub.
2. Enviar estes arquivos para a branch `main`.
3. Em **Settings > Pages > Build and deployment > Source**, selecionar **GitHub Actions**.
4. Fazer um novo push, se necessário.
5. Aguardar o workflow **Publicar no GitHub Pages** ficar verde.
6. Abrir a URL exibida pelo GitHub.

## Onde editar cada coisa

- **Texto e estrutura geral:** `index.html`
- **Animais, agentes, doenças, prevenção e “Saiba mais”:** `script.js`
- **Cores, tamanhos, cards e responsividade:** `style.css`
- **Imagens:** `assets/img/`

Consulte [`docs/GUIA_EDICAO_CONTEUDO.md`](docs/GUIA_EDICAO_CONTEUDO.md) antes de alterar conteúdo científico.

A documentação completa está indexada em [`docs/README.md`](docs/README.md).

## Regra científica importante

A página diferencia níveis de evidência. Encontrar um microrganismo em um animal **não significa automaticamente que esse animal transmite clinicamente a doença**. O conteúdo deve preservar expressões como “pode transportar”, “transporte documentado”, “carreador potencial” e “relação mais bem estabelecida” conforme o caso.

O rato também é tratado de forma especial: na leptospirose, ele aparece principalmente como **reservatório e fonte de contaminação ambiental**, não como um vetor mecânico clássico equivalente à mosca.

## Privacidade antes de publicar

Como o GitHub Pages deixa o site acessível publicamente, revise [`docs/PRIVACIDADE_E_PUBLICACAO.md`](docs/PRIVACIDADE_E_PUBLICACAO.md) antes da publicação definitiva, especialmente a forma de autoria dos estudantes.

## Antes da feira

Use o checklist operacional em [`docs/CHECKLIST_FEIRA.md`](docs/CHECKLIST_FEIRA.md). Leve também uma cópia local/offline do projeto no computador usado na apresentação.
